using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DisplayLives : MonoBehaviour
{

    public TMP_Text livesText;

    // Start is called before the first frame update
    void Start()
    {
        int livesCount = GameDataManager.gameData.lives;
        livesText.text = "Lives: " + livesCount.ToString();
    }

}
