using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO; // Add System.IO to work with files

public class GameDataManager : MonoBehaviour
{
    [System.Serializable]
    public class GameData {
        // Public 
        public int lives = 10;
        public string currentDungeon = "";
        public int currentNode = 0;
        public string nodeSprite = "";
        // state { locked = 0, unlocked = 1, completed = 2 }
        public int[] englishDungeon = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 };//represent 10 nodes in enum array
        public int[] historyDungeon = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        public int[] mathDungeon = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    }

    //public game data that everyone can use
    public static GameData gameData;

    void Awake()
    {
        //read saved data from file
        readFile();

    }

    public void readFile()
    {
        // Does the file exist?
        if (File.Exists(Application.dataPath + "/JSON/gamedata.json"))
        {
            // Read the entire file and save its contents.
            string json = File.ReadAllText(Application.dataPath + "/JSON/gamedata.json");

            // Deserialize the JSON data into a pattern matching the GameData class.
            gameData = JsonUtility.FromJson<GameData>(json);
        }
        else
        {
            //file does not exist so create a new one
            gameData = new GameData();
            string jsonString = JsonUtility.ToJson(gameData);
            File.WriteAllText(Application.dataPath + "/JSON/gamedata.json", jsonString);
        }
    }

    //public static to allow saving data before changing scenes
    public static void writeFile()
    {
        // Serialize the object into JSON and save string.
        string jsonString = JsonUtility.ToJson(gameData);

        // Write JSON to file.
        File.WriteAllText(Application.dataPath + "/JSON/gamedata.json", jsonString);
    }

}
