using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MakeChoice : MonoBehaviour
{
    public TMP_Text TextBox;

    public TMP_Text Atext;
    public TMP_Text Btext;
    public TMP_Text Ctext;
    public TMP_Text Dtext;


    public GameObject ShowQ;

    public GameObject Choose1;
    public GameObject Choose2;
    public GameObject Choose3;
    public GameObject Choose4;


    public GameObject Checker1;
    public GameObject Checker2;
    public GameObject Checker3;
    public GameObject Checker4;

    public string choicemade;
    public string answer;

    public bool made;


    void Start() 
    {

        setchoice();
    }

    public void setchoice() {

        int index = GameDataManager.gameData.currentNode;   //uses the currentNode variable to index the question 

        TextBox.text = QuestionDataManager.questionData.questions[index].question;  //get the question
        Atext.text = QuestionDataManager.questionData.questions[index].options[0];  //get the first option
        Btext.text = QuestionDataManager.questionData.questions[index].options[1];  //get the second option
        Ctext.text = QuestionDataManager.questionData.questions[index].options[2];  //get the third option
        Dtext.text = QuestionDataManager.questionData.questions[index].options[3];  //get the fourth option

        answer = QuestionDataManager.questionData.questions[index].answer;  //get the correct answer

        Checker1.SetActive(false);
        Checker2.SetActive(false);
        Checker3.SetActive(false);
        Checker4.SetActive(false);
        made = false;
    }

    public void select1() {
        made = true;
        
        Checker1.SetActive(true);
        Checker2.SetActive(false);
        Checker3.SetActive(false);
        Checker4.SetActive(false);
        choicemade = "a";


    }
    public void select2()
    {
        made = true;
       
        Checker1.SetActive(false);
        Checker2.SetActive(true);
        Checker3.SetActive(false);
        Checker4.SetActive(false);
        choicemade = "b";

    }
    public void select3()
    {
        made = true;
  
        Checker1.SetActive(false);
        Checker2.SetActive(false);
        Checker3.SetActive(true);
        Checker4.SetActive(false);
        choicemade = "c";

    }
    public void select4()
    {
        made = true;
        
        Checker1.SetActive(false);
        Checker2.SetActive(false);
        Checker3.SetActive(false);
        Checker4.SetActive(true);
        choicemade = "d";




    }

    public bool get_ifmade() {
        
        return made;
    
    
    }


    public bool evaluate_answer() {

        if (choicemade  == answer)
        {

           
            return true;

        }

        else {
            
            return false;
        }
            
            
    
    
    }


}
