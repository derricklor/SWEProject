using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class BattleHud : MonoBehaviour
{
    // Start is called before the first frame update
    public Text nameText;
    public Text lvlText;
    public Slider hpSlider;

    public void SetHUD(Unit unit) {

        nameText.text = unit.UnitName;
        lvlText.text = "";
        hpSlider.maxValue = unit.MaxHP;
        hpSlider.value = unit.CurrentHP;
    }
    public void SetHP(int hp)
    {
        hpSlider.value = hp;
    
    }

}
