using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;



public enum Battlestate { START, PLAYERTURN, ENEMYTURN, WON, LOST }
public class Battleprotocol : MonoBehaviour
{
    public GameObject popUpBox;
    public Animator animator;
    public TMP_Text popUpText;
    public bool tmp;

    public GameObject playerPrefab;
    public GameObject enemyPrefab;


    public GameObject Dragon;
    public GameObject Werewolf;
    public GameObject Sword;
    public GameObject Octopus;
    public GameObject Skull;


    public GameObject Musket;
    public GameObject Mite;
    public GameObject Hammer;
    public GameObject Helmet;
    public GameObject Arrow;
    public GameObject Squid;
    public GameObject Mimic;


    public Transform playerBattleStation;
    public Transform enemyBattleStation;

    Unit playerUnit;
    Unit enemyUnit;



    MakeChoice Selection;
    public Text DialogText;
    public Battlestate state;

    public BattleHud playerhud;
    public BattleHud enemyhud;




    // Start is called before the first frame update
    void Start()
    {
        Dragon.SetActive(false);
        Skull.SetActive(false);
        Octopus.SetActive(false);
        Werewolf.SetActive(false);
        Sword.SetActive(false);


        Musket.SetActive(false);
        Mite.SetActive(false);
        Hammer.SetActive(false);
        Helmet.SetActive(false);
        Arrow.SetActive(false);
        Mimic.SetActive(false);
        Squid.SetActive(false);


        state = Battlestate.START;
        Selection = GameObject.FindGameObjectWithTag("Dialogref").GetComponent<MakeChoice>();
        StartCoroutine(SetupBattle());
    }


    IEnumerator SetupBattle()
    {

        GameObject playerGO = Instantiate(playerPrefab, playerBattleStation);
        playerUnit = playerGO.GetComponent<Unit>();


        GameObject enemyGO = Instantiate(enemyPrefab, enemyBattleStation);
        enemyUnit = enemyGO.GetComponent<Unit>();
        setupdisplay();
        DialogText.text = enemyUnit.UnitName + " Approaches ";

        playerhud.SetHUD(playerUnit);

        enemyhud.SetHUD(enemyUnit);

        yield return new WaitForSeconds(2f);
        state = Battlestate.PLAYERTURN;
        PlayerTurn();

    }



    public void setupdisplay()
    {
 
        switch (GameDataManager.gameData.nodeSprite)
        {
            case "werewolf-white":
                enemyUnit.UnitName = "Werewolf";
                Werewolf.SetActive(true);
                break;
            case "wyvern-white":
                enemyUnit.UnitName = "Dragon";
                Dragon.SetActive(true);
                break;
            case "crowned-skull-white":
                enemyUnit.UnitName = "Skull";
                Skull.SetActive(true);
                break;
            case "octopus-white":
                enemyUnit.UnitName = "Octopus";
                Octopus.SetActive(true);
                break;
            case "pointy-sword-white":
                enemyUnit.UnitName = "Cursed Sword";
                Sword.SetActive(true);
                break;
            case "blunderbuss-white":
                enemyUnit.UnitName = "Cursed Gun";
                Musket.SetActive(true);
                break;
            case "mite-white":
                enemyUnit.UnitName = "Giant Mite";
                Mite.SetActive(true);
                break;
            case "pocket-bow-white":
                enemyUnit.UnitName = "Curse Bow";
                Arrow.SetActive(true);
                break;
            case "claw-hammer-white":
                enemyUnit.UnitName = "Cursed Hammer";
                Hammer.SetActive(true);
                break;
            case "horned-helm-white":
                enemyUnit.UnitName = "Viking Ghost";
                Helmet.SetActive(true);
                break;
            case "locked-chest-white":
                enemyUnit.UnitName = "mimic";
                Mimic.SetActive(true);
                break;
            case "squid-black":
                enemyUnit.UnitName = "Squid";
                Squid.SetActive(true);
                break;
        }


    }

    void modify_level(int node) {
        
        string t = GameDataManager.gameData.currentDungeon;

        switch (t)
        {
            case "English":
                GameDataManager.gameData.englishDungeon[node] = 2;
                break;
            case "History":
                GameDataManager.gameData.historyDungeon[node] = 2; 
                break;
            case "Math":
                GameDataManager.gameData.mathDungeon[node] = 2;
                break;
        }

    }
    
    
    
    void Endbattle()
    {
        if (state == Battlestate.WON)
        {
            /*
            if (GameDataManager.gameData.lives <10)
            {
                GameDataManager.gameData.lives += 1;
                DialogText.text = " You won! "+ GameDataManager.gameData.lives+ " ";

            }
            else if (GameDataManager.gameData.lives ==10)
                DialogText.text = " You won! current lives: "+ GameDataManager.gameData.lives+" ";
            */
            DialogText.text = " You won!";

            modify_level(GameDataManager.gameData.currentNode);


            PopUp(DialogText.text);
        }

        if (state == Battlestate.LOST)
        {
            if (GameDataManager.gameData.lives > 1)
            {
                GameDataManager.gameData.lives -= 1;
                DialogText.text = "You lost! -1 Life.";//+ GameDataManager.gameData.lives + " ";

            }
            else
            {
                ///////GAME OVER CALL
                DialogText.text = " GAME OVER! You lost all your progress.";

                for( int i = 0; i < 10; i++)
                {
                    //lock all nodes
                    GameDataManager.gameData.mathDungeon[i] = 0;
                    GameDataManager.gameData.englishDungeon[i] = 0;
                    GameDataManager.gameData.historyDungeon[i] = 0;
                }

                //make first node unlocked
                GameDataManager.gameData.mathDungeon[0] = 1;
                GameDataManager.gameData.englishDungeon[0] = 1;
                GameDataManager.gameData.historyDungeon[0] = 1;
                GameDataManager.gameData.lives = 10;

            }
            
            PopUp(DialogText.text);
        }

    }



    public void PopUp(string message)
    {
        popUpBox.SetActive(true);
        popUpText.text = message;
        animator.SetTrigger("pop");

    }



    IEnumerator PlayerAttack( bool isCorrect)
    {
        if (isCorrect) {
            bool isDEAD = enemyUnit.TakeDamage(playerUnit.damagelevel);
            enemyhud.SetHP(enemyUnit.CurrentHP);
            
            if (isDEAD)
            {
                state = Battlestate.WON;
                Endbattle();

            }
            else {
                state = Battlestate.ENEMYTURN;
                StartCoroutine(EnemyTurn("Correct! you hit for " + playerUnit.damagelevel + " points"));
            }
        }

        else {
             
           
            yield return new WaitForSeconds(1f);
            state = Battlestate.ENEMYTURN;
            StartCoroutine(EnemyTurn("Wrong choice!"));
        }

    }
    IEnumerator EnemyTurn(string message)
    {

        DialogText.text = message;
        yield return new WaitForSeconds(2f);
        DialogText.text = ""+ enemyUnit.UnitName + " hit you for " + enemyUnit.damagelevel + " points";
      
        yield return new WaitForSeconds(1f);

        bool isDEAD = playerUnit.TakeDamage(enemyUnit.damagelevel);

        playerhud.SetHP(playerUnit.CurrentHP);

        yield return new WaitForSeconds(1f);


        if (isDEAD)
        {
            state = Battlestate.LOST;
            Endbattle();

        }
        else
        {
            state = Battlestate.PLAYERTURN;
            PlayerTurn();
        }
    }

  
    void PlayerTurn()

    {
        DialogText.text = "To properly attack, check the correct answer then sumbit.";

    
    }

    public void OnButtonPressed()
    {
        tmp = Selection.get_ifmade();
        if (tmp)
        {
            bool isCorrect = Selection.evaluate_answer();

            if (state != Battlestate.PLAYERTURN)
                return;

            
            StartCoroutine(PlayerAttack(isCorrect));
            
        }
        else
            DialogText.text = " NO SELECTION MADE to properly attack check the correct answer then sumbit";


    }



}
