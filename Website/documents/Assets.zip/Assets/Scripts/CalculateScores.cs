using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CalculateScores : MonoBehaviour
{
    //drag and drop text mesh pro objects to bind with this script
    public TMP_Text englishSco;
    public TMP_Text historySco;
    public TMP_Text mathSco;

    // Start is called before the first frame update
    void Start()
    {
        //find number of encounters completed for each dungeon
        
        //set new text
        englishSco.text = getEngScore()+"/10";
        historySco.text = getHistScore()+"/10";
        mathSco.text = getMathScore()+"/10";
    }

    string getEngScore ()
    {
        int[] arr = GameDataManager.gameData.englishDungeon;
        int score = 0;
        for( int i = 0; i < 10; i++)
        {
            if (arr[i] == 2)
            {
                score++;
            }
        }
        return score.ToString();
    }

    string getHistScore()
    {
        int[] arr = GameDataManager.gameData.historyDungeon;
        int score = 0;
        for (int i = 0; i < 10; i++)
        {
            if (arr[i] == 2)
            {
                score++;
            }
        }
        return score.ToString();
    }

    string getMathScore()
    {
        int[] arr = GameDataManager.gameData.mathDungeon;
        int score = 0;
        for (int i = 0; i < 10; i++)
        {
            if (arr[i] == 2)
            {
                score++;
            }
        }
        return score.ToString();
    }

}
