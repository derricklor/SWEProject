using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameLogicTestScript : MonoBehaviour
{
    // Start is called before the first frame update
    public void DebugReturnQuestion()
    {
        //Debug.Log(GameDataManager.gameData.nodeSprite);
        Debug.Log(QuestionDataManager.questionData.questions[0].question);
        Debug.Log(1+1);
    }


}
