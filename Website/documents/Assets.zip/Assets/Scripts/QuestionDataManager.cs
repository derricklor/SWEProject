using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO; // Add System.IO to work with files

public class QuestionDataManager : MonoBehaviour
{
    [System.Serializable]
    public class Question
    {
        public string question = "default question ";
        public string answer = "default answer";
        public List<string> options;
    }

    [System.Serializable]
    public class QuestionData
    {
        // Public 
        public string dungeonName = "default";
        public int size = 10;
        public List<Question> questions = new List<Question>();
        
    }

    //public question data that everyone can use
    public static QuestionData questionData;

    void Start()
    {
        //read saved data from file
        readFile();
    }

    public void readFile()
    {
        string checkDungeon = GameDataManager.gameData.currentDungeon;
        string fileName;
        if (checkDungeon == "English")
        {
            fileName = "englishQs";
        }
        else if (checkDungeon == "Math")
        {
            fileName = "mathQs";
        }
        else
        {
            fileName = "historyQs";
        }

        // Does the file exist?
        if (File.Exists(Application.dataPath + "/JSON/" + fileName + ".json"))
        {
            // Read the entire file and save its contents.
            string json = File.ReadAllText(Application.dataPath + "/JSON/" + fileName + ".json");

            // Deserialize the JSON data into a pattern matching the QuestionData class.
            questionData = JsonUtility.FromJson<QuestionData>(json);
        }
        else
        {
            //file does not exist so create a new one
            questionData = new QuestionData();
            string jsonString = JsonUtility.ToJson(questionData);
            File.WriteAllText(Application.dataPath + "/JSON/" + fileName + ".json", jsonString);
        }
    }

}
