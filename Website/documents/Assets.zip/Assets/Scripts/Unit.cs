using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour
{
    public string UnitName;
    public int MaxHP;
    public int CurrentHP;
    public int damagelevel;
    public GameObject CurrentSprite;
    public int Level;
    Spritelist SpriteCollection;




    public bool TakeDamage(int dmg)
    {
        CurrentHP -= dmg;

        if (CurrentHP <= 0)
            return true;
        else
            return false;
    
    
    
    }
    public void SetSprite(int number)
    {

        SpriteCollection = GameObject.FindGameObjectWithTag("Spritelist").GetComponent<Spritelist>();
        CurrentSprite.GetComponent<SpriteRenderer>().sprite = SpriteCollection.pullSprite(number);

    }

}
