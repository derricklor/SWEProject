using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneChangeScript : MonoBehaviour
{
    //use for hardcoded static change between scenes
	public void ChangeScene(string sceneName)
	{
		//write player data to json file before changing scenes
		GameDataManager.writeFile();
		SceneManager.LoadScene(sceneName);
	}

    //use specifically in encounter to return to correct dungeon
    public void ChangeSceneFromEncountertoDungeon()
    {
        //write player data to json file before changing scenes
        GameDataManager.writeFile();
        string curdungeon = GameDataManager.gameData.currentDungeon;
        switch (curdungeon)
        {
            case "English":
                curdungeon = "englishDungeon";
                break;

            case "Math":
                curdungeon = "mathDungeon";
                break;

            default:
                curdungeon = "historyDungeon";
                break;
        }
        SceneManager.LoadScene(curdungeon);
    }

    //use specifically in dungeon to enter encounter
    public void ChangeSceneMathDungeonToEncounter(int node)
    {
        //set variables
        GameDataManager.gameData.currentNode = node;
        GameDataManager.gameData.currentDungeon = "Math";
        //find node sprite and save to gameData
        GameObject temp = GameObject.Find("ButtonEncounter" + node);
        GameDataManager.gameData.nodeSprite = temp.GetComponent<Image>().sprite.name;
        //write player data to json file before changing scenes
        GameDataManager.writeFile();
        SceneManager.LoadScene("encounter");
    }

    public void ChangeSceneEnglishDungeonToEncounter( int node)
    {
        //set variables
        GameDataManager.gameData.currentNode = node;
        GameDataManager.gameData.currentDungeon = "English";
        //find node sprite and save to gameData
        GameObject temp = GameObject.Find("ButtonEncounter" + node);
        GameDataManager.gameData.nodeSprite = temp.GetComponent<Image>().sprite.name;
        //write player data to json file before changing scenes
        GameDataManager.writeFile();
        SceneManager.LoadScene("encounter");
    }

    public void ChangeSceneHistoryDungeonToEncounter(int node)
    {
        //set variables
        GameDataManager.gameData.currentNode = node;
        GameDataManager.gameData.currentDungeon = "History";
        //find node sprite and save to gameData
        GameObject temp = GameObject.Find("ButtonEncounter" + node);
        GameDataManager.gameData.nodeSprite = temp.GetComponent<Image>().sprite.name;
        //write player data to json file before changing scenes
        GameDataManager.writeFile();
        SceneManager.LoadScene("encounter");
    }

    public void ReloadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void Exit()
	{
		//write player data to json file before quitting
		GameDataManager.writeFile();
		Application.Quit();
	}
}
