using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NodeManagerForMath : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        mathProgression();
        mathInteractability();
    }

    public void mathProgression()
    {
        //different progression for each dungeon
        int[] arr = GameDataManager.gameData.mathDungeon;

        // state { locked = 0, unlocked = 1, completed = 2 }
        //unlock pathways if encounter is completed
        if (arr[0] == 2 && arr[1] != 2)
        {
            GameDataManager.gameData.mathDungeon[1] = 1;
        }
        if (arr[1] == 2 && arr[2] != 2 && arr[3] != 2)
        {
            GameDataManager.gameData.mathDungeon[2] = 1;
            GameDataManager.gameData.mathDungeon[3] = 1;
        }
        if (arr[2] == 2 && arr[3] == 2 && arr[4] != 2)
        {
            GameDataManager.gameData.mathDungeon[4] = 1;
        }
        if ( arr[4] == 2 && arr[5] != 2  && arr[6] != 2)
        {
            GameDataManager.gameData.mathDungeon[5] = 1;
            GameDataManager.gameData.mathDungeon[6] = 1;
        }
        if (arr[5] == 2 && arr[6] == 2 && arr[7] != 2)
        {
            GameDataManager.gameData.mathDungeon[7] = 1;
        }
        if (arr[7] == 2 && arr[8] != 2)
        {
            GameDataManager.gameData.mathDungeon[8] = 1;
        }
        if (arr[8] == 2 && arr[9] != 2)
        {
            GameDataManager.gameData.mathDungeon[9] = 1;
        }

        //save data
        GameDataManager.writeFile();
    }

    public void mathInteractability()
    {
        //Change the color and button interactability of a node based on gameData
        for (int i = 0; i < 10; i++)
        {
            //find the specific node with name
            GameObject temp = GameObject.Find("ButtonEncounter" + i);

            // state { locked = 0, unlocked = 1, completed = 2 }

            if (GameDataManager.gameData.mathDungeon[i] == 0)
            {
                //make node black and disable button interactable
                temp.GetComponent<Image>().color = Color.black;
                temp.GetComponent<Button>().interactable = false;
            }

            if (GameDataManager.gameData.mathDungeon[i] == 1)
            {
                //make node yellow and enable button interactable
                temp.GetComponent<Image>().color = Color.yellow;
                temp.GetComponent<Button>().interactable = true;
            }

            if (GameDataManager.gameData.mathDungeon[i] == 2)
            {
                //make node white and disable button interactable
                temp.GetComponent<Image>().color = Color.white;
                temp.GetComponent<Button>().interactable = false;
            }

        }
    }

}
