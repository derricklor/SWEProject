using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spritelist : MonoBehaviour
{
    public Sprite Skull;
    public Sprite Sword;
    public Sprite Dragon;



    // Start is called before the first frame update
    public Sprite pullSprite(int number) {


        if (number==1) {
            return Skull;
        }
        else if (number==2) {
            return Sword;
        }
        else 
            return Dragon;
        
    
    
    
    }

   
}
